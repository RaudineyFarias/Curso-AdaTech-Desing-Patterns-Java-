package br.com.ada.designpattern.chainofresponsibility;

public enum Marca {

    FIAT,
    FORD,
    CHEVROLET
}
