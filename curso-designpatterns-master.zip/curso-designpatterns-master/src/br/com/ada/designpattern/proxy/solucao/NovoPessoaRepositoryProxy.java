package br.com.ada.designpattern.proxy.solucao;

import br.com.ada.designpattern.proxy.PessoaRepository;

public class NovoPessoaRepositoryProxy extends PessoaRepository implements ProxyPessoa{
}
