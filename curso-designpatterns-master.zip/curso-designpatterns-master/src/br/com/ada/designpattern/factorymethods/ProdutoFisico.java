package br.com.ada.designpattern.factorymethods;

public class ProdutoFisico extends Produto{
}
