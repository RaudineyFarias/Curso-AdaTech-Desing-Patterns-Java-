package br.com.ada.designpattern.factorymethods;

public class ProdutoDigital extends Produto{
}
