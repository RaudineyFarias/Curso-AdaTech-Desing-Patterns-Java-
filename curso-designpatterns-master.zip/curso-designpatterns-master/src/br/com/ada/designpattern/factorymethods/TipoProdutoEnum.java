package br.com.ada.designpattern.factorymethods;

public enum TipoProdutoEnum {

    FISICO,
    DIGITAL;
}
