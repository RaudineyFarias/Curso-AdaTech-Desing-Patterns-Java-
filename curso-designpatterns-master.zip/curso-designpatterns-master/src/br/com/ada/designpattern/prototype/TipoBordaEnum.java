package br.com.ada.designpattern.prototype;

public enum TipoBordaEnum {

    FINA, GROSSA, TRACEJADA;
}
