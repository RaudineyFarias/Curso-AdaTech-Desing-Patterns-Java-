package br.com.ada.designpattern.builder.problema;

import br.com.ada.designpattern.builder.Pessoa;
import br.com.ada.designpattern.builder.solucao.Animal;

import java.time.LocalDate;

public class TestePessoa {

    public static void main(String[] args) {
        // construtor de pessoa foi marcado como privado
        /*Pessoa pessoa = new Pessoa("Anderson",
                "Piotto",
                "09876554323",
                "piottok10@gmail.com",
                "careca",
                LocalDate.of(1985,03,12));*/

        //System.out.println(pessoa);

    }
}
