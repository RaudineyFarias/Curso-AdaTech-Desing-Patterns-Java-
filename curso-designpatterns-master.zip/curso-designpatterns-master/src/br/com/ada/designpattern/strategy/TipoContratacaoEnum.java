package br.com.ada.designpattern.strategy;

public enum TipoContratacaoEnum {

    CLT,
    PJ,
    ESTAGIO,

    COOPERATIVA;
}
