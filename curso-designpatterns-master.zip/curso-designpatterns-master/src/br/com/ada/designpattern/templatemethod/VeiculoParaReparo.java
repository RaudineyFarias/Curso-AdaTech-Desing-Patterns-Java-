package br.com.ada.designpattern.templatemethod;

public class VeiculoParaReparo {

    private int porcentagemDano;

    public int getPorcentagemDano() {
        return porcentagemDano;
    }

    public void setPorcentagemDano(int porcentagemDano) {
        this.porcentagemDano = porcentagemDano;
    }
}
